(function ($) {
    "use strict";

    $('#summernote').summernote({
        placeholder: 'Hello Bootstrap 4',
        tabsize: 2,
        height: 250
    });

})(jQuery);