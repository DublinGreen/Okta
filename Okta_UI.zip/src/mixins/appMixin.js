// import store from "../store";

export const appMixin = {
  methods: {
    logout() {
    },
    isLoggedIn() {
    }
  }
};
